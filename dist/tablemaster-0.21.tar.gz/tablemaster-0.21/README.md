# tablemaster
A Python package makes it easy to manage tables anywhere.
